﻿# 用真实 HTTP 请求跑一遍牛棚数据看板的核心流程。
# 用法： powershell -ExecutionPolicy Bypass -File scripts/acceptance.ps1 [-Keep]
#
# 本机只有 Windows PowerShell 5.1（没装 pwsh 7）。5.1 的 Invoke-WebRequest /
# Invoke-RestMethod 会把字符串 body 按 Latin-1 发出去、把响应按 ISO-8859-1 解码，
# 中文会变成 ?，红线的 400 断言会假失败成 422。所以这里统一自己编解码 UTF-8 字节。
#
# -Keep 保留临时项目目录，供人打开浏览器人工核对。
param([switch]$Keep)

$ErrorActionPreference = "Stop"
$base = "http://127.0.0.1:8765"
$tmp = Join-Path $env:TEMP ("niupeng-acceptance-" + [guid]::NewGuid().ToString("N").Substring(0, 8))
New-Item -ItemType Directory -Force -Path $tmp | Out-Null

# 这个脚本会通过 POST /api/root 改写 ~/.niupeng-board.json，跑完必须还原
$configPath = Join-Path $HOME ".niupeng-board.json"
$configBackup = Join-Path $env:TEMP ("niupeng-config-" + [guid]::NewGuid().ToString("N").Substring(0, 8) + ".json")
$hadConfig = Test-Path $configPath
if ($hadConfig) { Copy-Item $configPath $configBackup -Force }

$script:checks = 0
$script:failures = 0

function Assert-Equal($label, $expected, $actual) {
  $script:checks++
  if ("$expected" -eq "$actual") {
    Write-Output ("PASS  {0} => {1}" -f $label, $actual)
  } else {
    $script:failures++
    Write-Output ("FAIL  {0} => 期望 {1}，实际 {2}" -f $label, $expected, $actual)
  }
}

function Invoke-Api($method, $path, $body) {
  $params = @{
    Method      = $method
    Uri         = "$base$path"
    ContentType = "application/json; charset=utf-8"
  }
  if ($null -ne $body) {
    $json = $body | ConvertTo-Json -Depth 6 -Compress
    $params.Body = [Text.Encoding]::UTF8.GetBytes($json)
  }
  try {
    $response = Invoke-WebRequest @params -UseBasicParsing
    $status = [int]$response.StatusCode
    $text = [Text.Encoding]::UTF8.GetString($response.RawContentStream.ToArray())
  } catch {
    $webResponse = $_.Exception.Response
    if ($null -eq $webResponse) {
      # 服务没起来时 Response 是 $null。不抛的话状态码会变成 0，
      # 整个脚本会假装"跑完了"，所有断言静默变 0。
      throw "连不上 $base$path —— 服务启动了吗？（$($_.Exception.Message)）"
    }
    $status = [int]$webResponse.StatusCode
    $reader = New-Object System.IO.StreamReader($webResponse.GetResponseStream(), [Text.Encoding]::UTF8)
    $text = $reader.ReadToEnd()
    $reader.Close()
  }
  $payload = $null
  if ($text) { try { $payload = $text | ConvertFrom-Json } catch { $payload = $null } }
  return [pscustomobject]@{ Status = $status; Data = $payload }
}

function Code($method, $path, $body) { return (Invoke-Api $method $path $body).Status }
function Call($method, $path, $body) { return (Invoke-Api $method $path $body).Data }

Write-Output "临时项目目录: $tmp"
Write-Output ""

Assert-Equal "POST /api/root（未初始化）" 200 (Code POST "/api/root" @{ path = $tmp })
Assert-Equal "POST /api/init" 200 (Code POST "/api/init" $null)
Assert-Equal "POST /api/root（错误路径）" 400 (Code POST "/api/root" @{ path = (Join-Path $tmp "nope") })

$task = Call POST "/api/tasks" @{ title = "支持日历导出"; source = "human"; detail = "希望导出 ics"; priority = "P1" }
Assert-Equal "新建任务 id" "T-0001" $task.id
Assert-Equal "新建任务 status" "new" $task.status
Assert-Equal "中文往返（title）" "支持日历导出" $task.title

# 红线：评估完成 只能走 /approve
Assert-Equal "PATCH status=评估完成（应 400）" 400 (Code PATCH "/api/tasks/$($task.id)" @{ status = "评估完成"; note = "偷偷放行" })
Assert-Equal "PATCH status 缺 note（应 400）" 400 (Code PATCH "/api/tasks/$($task.id)" @{ status = "reject" })
# 人类是外部来源：任意状态之间自由切换，没有 force/confirm 之类的门槛
Assert-Equal "PATCH new 直接跳 开发中" 200 (Code PATCH "/api/tasks/$($task.id)" @{ status = "开发中"; note = "我自己推进" })
Assert-Equal "PATCH 开发中 回到 需求评估中" 200 (Code PATCH "/api/tasks/$($task.id)" @{ status = "需求评估中"; note = "回头补评估" })
Assert-Equal "旧版 force 字段已删除（应 400）" 400 (Code PATCH "/api/tasks/$($task.id)" @{ title = "x"; force = $true; confirm = $true })
Assert-Equal "approve" 200 (Code POST "/api/tasks/$($task.id)/approve" @{})
Assert-Equal "approve 第二次（应 409）" 409 (Code POST "/api/tasks/$($task.id)/approve" @{})

$after = (Call GET "/api/state" $null).tasks[0]
Assert-Equal "放行后 status" "评估完成" $after.status
Assert-Equal "放行后 notes 条数" 3 $after.notes.Count
Assert-Equal "放行后最后一条 note" "外部来源放行开发" $after.notes[-1].text

Assert-Equal "PATCH 陈旧 expectedUpdatedAt（应 409）" 409 (Code PATCH "/api/tasks/$($task.id)" @{ title = "x"; expectedUpdatedAt = "2026-01-01T00:00:00+08:00" })

$bug = Call POST "/api/bugs" @{ title = "导出后文件名乱码"; severity = "major"; taskId = $task.id; steps = "点导出" }
Assert-Equal "新建 bug id" "B-0001" $bug.id
Assert-Equal "bug 直接跳到 已关闭（无白名单）" 200 (Code PATCH "/api/bugs/$($bug.id)" @{ status = "已关闭"; note = "环境问题" })
Assert-Equal "bug 从终态重开" 200 (Code PATCH "/api/bugs/$($bug.id)" @{ status = "修复中"; note = "又出现了" })
Assert-Equal "bug 关联不存在的任务（应 400）" 400 (Code POST "/api/bugs" @{ title = "t"; severity = "minor"; taskId = "T-0999" })

$msg = Call POST "/api/messages" @{ to = "dsh"; subject = "本轮冲刺说明"; body = "请看设计文档" }
Assert-Equal "新建站内信 from" "human" $msg.from
Assert-Equal "创建消息带 from（应 400）" 400 (Code POST "/api/messages" @{ from = "analyst"; to = "dsh"; subject = "s"; body = "b" })
Assert-Equal "回信指向不存在的消息（应 400）" 400 (Code POST "/api/messages" @{ to = "dsh"; subject = "s"; body = "b"; inReplyTo = "M-0999" })
Assert-Equal "GET /api/docs/a.txt（应 400）" 400 (Code GET "/api/docs/a.txt" $null)
Assert-Equal "GET /api/docs/S-2026-01-01.md（应 404）" 404 (Code GET "/api/docs/S-2026-01-01.md" $null)

$state = Call GET "/api/state" $null
Assert-Equal "counts.tasks" 1 $state.counts.tasks
Assert-Equal "counts.bugs" 1 $state.counts.bugs
Assert-Equal "counts.inbox" 1 $state.counts.inbox

Write-Output ""
Write-Output "--- 落盘文件 ---"
Get-ChildItem -Recurse -File (Join-Path $tmp ".niupeng") |
  ForEach-Object { Write-Output ("  " + $_.FullName.Substring($tmp.Length + 1)) }
Write-Output "--- tasks/$($task.id).json ---"
# 必须显式 -Encoding UTF8：PS 5.1 的 Get-Content 默认按 ANSI(GBK) 读，
# 会把正确的 UTF-8 中文显示成乱码，让人误判"工具把数据写坏了"。
Get-Content (Join-Path $tmp ".niupeng\tasks\$($task.id).json") -Raw -Encoding UTF8

# --- 清理：配置一定要还原；临时目录默认删掉，-Keep 时留下供人工核对 ---
if ($hadConfig) {
  Copy-Item $configBackup $configPath -Force   # Copy-Item 保字节，避免 BOM 把配置文件读坏
  Remove-Item $configBackup -Force
} elseif (Test-Path $configPath) {
  Remove-Item $configPath -Force
}
if ($Keep) {
  Write-Output "保留了临时项目目录（-Keep）：$tmp"
} else {
  Remove-Item $tmp -Recurse -Force
}

Write-Output ""
Write-Output ("检查 {0} 项，失败 {1} 项" -f $script:checks, $script:failures)
if ($script:failures -gt 0) { exit 1 }
