# 牛棚数据看板 niupeng-board

给「牛棚」（DSH 的三人软件开发小团队 preset）的**外部来源（人类）**用的本地界面，
用来维护 `.niupeng/` 下的三份数据列表。

牛棚团队的唯一事实来源是磁盘上的 JSON 文件，一条记录一个文件，
所以这个工具就是那些文件的一个体面编辑器 —— 它不启动牛棚、不调度 agent、不改 preset。

## 安装与启动

```bash
uv sync                        # 建虚拟环境、装依赖
uv run niupeng-board           # 默认 http://127.0.0.1:8765
uv run niupeng-board --root D:\files\projects\你的项目
uv run niupeng-board --port 9000
```

只监听 `127.0.0.1`，无认证 —— 这是单用户本地工具。

打开界面后，在「项目目录」里填**被牛棚开发的那个项目的根目录**（不是 `.niupeng/` 本身）。
如果那个项目还没有 `.niupeng/`，点「初始化数据目录」一键建骨架。

上次用过的项目目录记在 `~/.niupeng-board.json`；`--root` 优先于它且不回写。

## 数据目录

```
<项目目录>/.niupeng/
  README.md    数据契约（初始化时从 preset 资产复制，已存在则不覆盖）
  tasks/       任务列表    T-0001.json
  bugs/        bug 列表    B-0001.json
  inbox/       站内信      M-0001.json
  docs/        需求说明 / 功能设计 / 开发执行计划（只读）
```

## 你要做的两件事

1. **加需求** —— 任务标签页「新建任务」。`status` 固定为 `new`。
2. **放行开发** —— 行上的「放行开发」按钮（`new` 状态显示为「跳过评估直接放行」）。
   这是唯一能让开发动手的方式。

## 红线

**任务状态 `评估完成` 只有人类能写。**

- 界面里只能通过「放行开发」按钮写入，走 `POST /api/tasks/{id}/approve`。
- 普通 `PATCH /api/tasks/{id}` 收到 `status: "评估完成"` 一律 `400`。
- 团队成员（含棚主与分析师）都不许写这个状态。界面是人类的工具，所以它能写 —— 但只有这一条通道。
- **放行端点对任意状态开放** —— 你不需要先等分析师评估。从 `new` 直接放行也行，
  只是 `notes` 会记下「人类跳过分析师评估直接放行」，团队看得到。

### 红线是纪律，不是技术强制

契约的红线本质靠**约定**：agent 本来就能用自己的文件写入工具直接改 `.niupeng/tasks/*.json`，
绕过任何界面。本工具没有让它更糟，但也**没有真正拦住 agent** —— 任何本机进程都能访问
`127.0.0.1:8765` 调 `/approve`。把它当成「给人类用的、方便且不易出错的界面」，
而不是一道安全边界。

## 状态可以随便改

**你是外部来源，任何状态都能改成任何状态**，没有转换白名单，也没有 `force`/`confirm` 之类的门槛：

- `new` 可以直接跳到 `开发中`；`开发中` 可以退回 `需求评估中`
- 终态（`已完成` / `reject`）可以随时重开 —— 契约说「除非人类明确要求重开」，你点一下就是明确要求
- bug 同理：`new` 可以直接关，关了可以重开，`taskId` 关联随时可以改

唯一的强制项是：**改状态必须留一条原因**（`notes`）。这是契约要求团队能看到「为什么」。
界面上留空会自动填一句如实说明（例如「人类把状态从「开发中」改为「需求评估中」」），所以不会挡路。

## 状态取值（逐字一致，不要改写）

- 任务：`new`、`需求评估中`、`评估完成`、`开发中`、`开发完成`、`验证中`、`已完成`、`reject`
- bug：`new`、`已确认`、`修复中`、`待验证`、`已关闭`、`reject`
- 严重程度：`blocker`、`major`、`minor`、`trivial`
- 优先级：`P0`、`P1`、`P2`、`P3`

## 人类能改哪些字段

| 记录 | 可直接改 | 不可改 |
| --- | --- | --- |
| 任务 | `title` `detail` `priority` `sprint` `designDoc` `owner` `relatedBugs` `status` | `id` `source` `createdAt` `updatedAt` |
| bug | `title` `severity` `steps` `expected` `actual` `env` `taskId` `status` | `id` `createdAt` `updatedAt` |
| 站内信 | 不可改 —— 消息发出即定稿，要更正就再发一条 | 全部 |

`designDoc` / `owner` / `relatedBugs` 在契约里属于分析师与质量测试维护，但你是外部来源，可以直接改
（`updatedAt` 会更新，团队下次开工就看到新值）。

`notes` 只能追加：改状态必须给原因（`note`），服务端强制。

`id` / `createdAt` / `updatedAt` 出现在请求体里即 `400` —— `id` 就是文件名，改了会和磁盘对不上。

## 并发安全

牛棚三名成员在后台同时读写同一批文件，所以：

- **原子写** —— 先写带 pid/线程 id 的唯一临时文件再 `os.replace`，不会产生半截 JSON，
  也不会因为两个写入者共用 `.tmp` 名而互相截断
- **编号独占创建** —— `O_CREAT|O_EXCL`，撞号就顺延重试，不会与 QA 建号冲突
- **宽容读取** —— 某条记录坏了（含非 UTF-8 编码的文件）只让那一行变成红色错误行，不影响其余记录
- **未知字段保留** —— 契约字段集之外的内容在 PATCH 时原样保留，不做静默删除
- **乐观锁** —— 你的详情抽屉开着时若 agent 改了同一条，保存会被 `409` 拦下并提示刷新，不会静默覆盖
  - 已知限制：契约要求 `updatedAt` 是秒级 ISO 8601，所以**同一秒内**的改动区分不出来。
    抽屉通常开着数秒到数分钟，这个窗口可以接受 —— 它是防误覆盖的安全网，不是并发正确性保证。

## 开发

```bash
uv run pytest -q                          # 全部测试（121 个用例）
```

```powershell
# 真实 HTTP 流程验收（需先启动服务；本机只有 Windows PowerShell 5.1，没有 pwsh 7）
powershell -ExecutionPolicy Bypass -File scripts/acceptance.ps1
```

> **改 `scripts/acceptance.ps1` 时必须存成 UTF-8 with BOM。**
> Windows PowerShell 5.1 读 `.ps1` 文件时，没有 BOM 就按系统 ANSI（中文 Windows 上是 GBK）解码，
> 脚本里的中文会全变乱码并直接语法报错。很多编辑器/工具默认写无 BOM 的 UTF-8，改完记得确认头三字节是 `EF BB BF`：
>
> ```powershell
> $p = "scripts\acceptance.ps1"
> $t = [IO.File]::ReadAllText($p, [Text.Encoding]::UTF8)
> [IO.File]::WriteAllText($p, $t, (New-Object Text.UTF8Encoding($true)))
> ```

设计文档：`docs/superpowers/specs/2026-09-19-niupeng-board-design.md`
实施计划：`docs/superpowers/plans/2026-09-19-niupeng-board.md`
