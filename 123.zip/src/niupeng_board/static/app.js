// 牛棚数据看板前端。原生 ES module，无构建步骤。
// 约定：所有来自磁盘或用户输入的内容在插入 DOM 前一律 escapeHtml。

const TASK_STATUSES = ["new", "需求评估中", "评估完成", "开发中", "开发完成", "验证中", "已完成", "reject"];
const BUG_STATUSES = ["new", "已确认", "修复中", "待验证", "已关闭", "reject"];
const SEVERITIES = ["blocker", "major", "minor", "trivial"];
const PRIORITIES = ["P0", "P1", "P2", "P3"];

const STATUS_CLASS = {
  "new": "new",
  "需求评估中": "analyzing",
  "评估完成": "approved",
  "开发中": "developing",
  "开发完成": "developed",
  "验证中": "verifying",
  "已完成": "done",
  "reject": "reject",
  "已确认": "analyzing",
  "修复中": "developing",
  "待验证": "verifying",
  "已关闭": "done",
};

let STATE = { root: null, connected: false, initialized: false, counts: {}, tasks: [], bugs: [], inbox: [], docs: [] };
let activeTab = "tasks";
let taskFilter = "全部";
let bugFilter = "全部";
let bugSeverityFilter = "全部";
let toastSeq = 0;

const $ = (id) => document.getElementById(id);

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

// 顺序很重要：先转义再套用 markdown 规则，绝不能让原文里的标签活过来。
function renderMarkdown(text) {
  const lines = escapeHtml(text ?? "").split(/\r?\n/);
  const out = [];
  let inCode = false;
  let inList = false;
  for (const line of lines) {
    if (line.trimStart().startsWith("```")) {
      if (inList) { out.push("</ul>"); inList = false; }
      out.push(inCode ? "</code></pre>" : "<pre><code>");
      inCode = !inCode;
      continue;
    }
    if (inCode) { out.push(line); continue; }
    if (/^\s*[-*]\s+/.test(line)) {
      if (!inList) { out.push("<ul>"); inList = true; }
      out.push("<li>" + inline(line.replace(/^\s*[-*]\s+/, "")) + "</li>");
      continue;
    }
    if (inList) { out.push("</ul>"); inList = false; }
    const heading = line.match(/^(#{1,6})\s+(.*)$/);
    if (heading) {
      const level = Math.min(heading[1].length, 3);
      out.push(`<h${level}>` + inline(heading[2]) + `</h${level}>`);
      continue;
    }
    if (!line.trim()) { out.push(""); continue; }
    out.push("<p>" + inline(line) + "</p>");
  }
  if (inList) out.push("</ul>");
  if (inCode) out.push("</code></pre>");
  return out.join("\n");
}

function inline(text) {
  return text
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_, label, href) =>
      // 只放行 http(s)：escapeHtml 挡得住引号注入，挡不住 javascript: 伪协议。
      /^https?:\/\//i.test(href)
        ? `<a href="${href}" target="_blank" rel="noreferrer">${label}</a>`
        : `${label}（${href}）`
    );
}

function toast(message, kind = "info") {
  const el = document.createElement("div");
  el.className = "toast" + (kind === "info" ? "" : " " + kind);
  el.textContent = message;
  const id = ++toastSeq;
  el.dataset.id = String(id);
  $("toasts").appendChild(el);
  setTimeout(() => el.remove(), kind === "info" ? 2600 : 6000);
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  let payload = null;
  try { payload = await response.json(); } catch { /* 空响应 */ }
  if (!response.ok) {
    const message = (payload && payload.error) || `请求失败（HTTP ${response.status}）`;
    const error = new Error(message);
    error.status = response.status;
    throw error;
  }
  return payload;
}

function applyState(next) {
  STATE = next;
  $("status").textContent = !next.connected ? "未连接" : (next.initialized ? "已连接" : "已连接未初始化");
  $("status").className = "badge " + (!next.connected ? "" : (next.initialized ? "ok" : "warn"));
  // 轮询每 5 秒跑一次，别把用户正在输入的路径覆盖掉
  if (next.root && document.activeElement !== $("root")) $("root").value = next.root;
  $("init").hidden = !(next.connected && !next.initialized);
  $("counts").textContent = next.connected
    ? `任务 ${next.counts.tasks ?? 0} · Bug ${next.counts.bugs ?? 0} · 站内信 ${next.counts.inbox ?? 0} · 文档 ${next.counts.docs ?? 0}`
    : "";
  render();
}

async function refresh(quiet = true) {
  try {
    const next = await api("/api/state");
    applyState(next);
    $("refreshed").textContent = "上次刷新 " + new Date().toLocaleTimeString();
  } catch (error) {
    if (error.status === 409) {
      $("counts").textContent = "";
      return; // 还没连接，不是错误
    }
    if (!quiet) toast(error.message, "error");
    else $("refreshed").textContent = "离线：无法刷新";
  }
}

function showNotice(text) {
  const el = $("notice");
  el.textContent = text;
  el.hidden = false;
  clearTimeout(showNotice.timer);
  showNotice.timer = setTimeout(() => { el.hidden = true; }, 8000);
}

function clearNotice() {
  $("notice").hidden = true;
}

async function connect() {
  const path = $("root").value.trim();
  if (!path) { toast("请先填项目目录", "warn"); return; }
  try {
    const next = await api("/api/root", { method: "POST", body: JSON.stringify({ path }) });
    localStorage.setItem("niupengBoard.root", next.root || path);
    applyState(next);
    toast("已连接 " + (next.root || path));
  } catch (error) {
    toast(error.message, "error");
  }
}

async function initialise() {
  try {
    applyState(await api("/api/init", { method: "POST" }));
    toast("数据目录已初始化");
  } catch (error) {
    toast(error.message, "error");
  }
}

function statusTag(status) {
  return `<span class="tag ${STATUS_CLASS[status] || "new"}">${escapeHtml(status)}</span>`;
}

function priorityTag(priority) {
  return `<span class="tag sev-trivial">${escapeHtml(priority)}</span>`;
}

function severityTag(severity) {
  return `<span class="tag sev-${escapeHtml(severity)}">${escapeHtml(severity)}</span>`;
}

function emptyRow(colspan, text) {
  return `<tr><td colspan="${colspan}"><div class="empty">${escapeHtml(text)}</div></td></tr>`;
}

function renderTasks() {
  const panel = $("panel-tasks");
  if (!STATE.connected) { panel.innerHTML = `<div class="empty">先连接一个项目目录。</div>`; return; }
  if (!STATE.initialized) { panel.innerHTML = `<div class="empty">这个项目还没有 .niupeng/，点上面的「初始化数据目录」。</div>`; return; }

  const all = STATE.tasks;
  const counts = {};
  for (const row of all) {
    if (row.ok) counts[row.status] = (counts[row.status] || 0) + 1;
  }
  const filterButtons = ["全部", ...TASK_STATUSES]
    .map((s) => {
      const n = s === "全部" ? all.length : (counts[s] || 0);
      const active = taskFilter === s ? " primary" : "";
      return `<button class="filter${active}" data-filter="${escapeHtml(s)}">${escapeHtml(s)} ${n}</button>`;
    })
    .join("");

  const rows = all
    .filter((row) => taskFilter === "全部" || row.status === taskFilter)
    .sort((a, b) => {
      const pa = PRIORITIES.indexOf(a.priority);
      const pb = PRIORITIES.indexOf(b.priority);
      if (pa !== pb) return (pa < 0 ? 99 : pa) - (pb < 0 ? 99 : pb);
      return String(b.updatedAt).localeCompare(String(a.updatedAt));
    })
    .map((row) => {
      if (!row.ok) {
        return `<tr class="error-row"><td colspan="9">${escapeHtml(row.file)} — ${escapeHtml(row.error)}</td></tr>`;
      }
      const actions = [];
      if (row.status !== "评估完成") {
        const skipping = row.status === "new";
        const attr = skipping ? "data-approve-skip" : "data-approve";
        const cls = skipping ? "" : ' class="approve"';
        const label = skipping ? "跳过评估直接放行" : "放行开发";
        actions.push(`<button${cls} ${attr}="${escapeHtml(row.id)}">${label}</button>`);
      }
      if (row.status !== "reject") {
        actions.push(`<button class="danger" data-reject="${escapeHtml(row.id)}">驳回</button>`);
      }
      return `<tr>
        <td>${escapeHtml(row.id)}</td>
        <td><a href="#" data-open-task="${escapeHtml(row.id)}">${escapeHtml(row.title)}</a></td>
        <td>${escapeHtml(row.source)}</td>
        <td>${statusTag(row.status)}</td>
        <td>${priorityTag(row.priority)}</td>
        <td>${escapeHtml(row.sprint ?? "")}</td>
        <td>${escapeHtml(row.owner ?? "")}</td>
        <td>${escapeHtml(row.updatedAt)}</td>
        <td class="actions">${actions.join(" ")}</td>
      </tr>`;
    })
    .join("");

  panel.innerHTML = `
    <div class="toolbar">
      <button id="new-task" class="primary">新建任务</button>
      <span class="muted">筛选：</span>${filterButtons}
    </div>
    <table>
      <thead><tr>
        <th>id</th><th>标题</th><th>source</th><th>status</th><th>priority</th>
        <th>sprint</th><th>owner</th><th>updatedAt</th><th></th>
      </tr></thead>
      <tbody>${rows || emptyRow(9, "这个筛选下没有任务")}</tbody>
    </table>`;
}

function renderBugs() {
  const panel = $("panel-bugs");
  if (!STATE.connected || !STATE.initialized) {
    panel.innerHTML = `<div class="empty">先连接并初始化一个项目目录。</div>`;
    return;
  }
  const all = STATE.bugs;
  const statusButtons = ["全部", ...BUG_STATUSES]
    .map((s) => {
      const n = s === "全部" ? all.length : all.filter((r) => r.ok && r.status === s).length;
      return `<button class="filter${bugFilter === s ? " primary" : ""}" data-bug-filter="${escapeHtml(s)}">${escapeHtml(s)} ${n}</button>`;
    })
    .join("");
  const severityButtons = ["全部", ...SEVERITIES]
    .map((s) => {
      const n = s === "全部" ? all.length : all.filter((r) => r.ok && r.severity === s).length;
      return `<button class="filter${bugSeverityFilter === s ? " primary" : ""}" data-severity-filter="${escapeHtml(s)}">${escapeHtml(s)} ${n}</button>`;
    })
    .join("");

  const rows = all
    .filter((row) => bugFilter === "全部" || row.status === bugFilter)
    .filter((row) => bugSeverityFilter === "全部" || row.severity === bugSeverityFilter)
    .map((row) => {
      if (!row.ok) {
        return `<tr class="error-row"><td colspan="6">${escapeHtml(row.file)} — ${escapeHtml(row.error)}</td></tr>`;
      }
      return `<tr>
        <td>${escapeHtml(row.id)}</td>
        <td><a href="#" data-open-bug="${escapeHtml(row.id)}">${escapeHtml(row.title)}</a></td>
        <td>${escapeHtml(row.taskId ?? "—")}</td>
        <td>${severityTag(row.severity)}</td>
        <td>${statusTag(row.status)}</td>
        <td>${escapeHtml(row.updatedAt)}</td>
      </tr>`;
    })
    .join("");

  panel.innerHTML = `
    <div class="toolbar">
      <button id="new-bug" class="primary">新建 Bug</button>
      <span class="muted">状态：</span>${statusButtons}
    </div>
    <div class="toolbar">
      <span class="muted">严重程度：</span>${severityButtons}
    </div>
    <table>
      <thead><tr><th>id</th><th>标题</th><th>taskId</th><th>severity</th><th>status</th><th>updatedAt</th></tr></thead>
      <tbody>${rows || emptyRow(6, "没有匹配的 bug")}</tbody>
    </table>`;
}

function renderInbox() {
  const panel = $("panel-inbox");
  if (!STATE.connected || !STATE.initialized) {
    panel.innerHTML = `<div class="empty">先连接并初始化一个项目目录。</div>`;
    return;
  }
  const rows = STATE.inbox
    .slice()
    .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))
    .map((row) => {
      if (!row.ok) {
        return `<tr class="error-row"><td colspan="6">${escapeHtml(row.file)} — ${escapeHtml(row.error)}</td></tr>`;
      }
      const read = (row.readBy || []).length ? row.readBy.join("、") : "未读";
      return `<tr>
        <td>${escapeHtml(row.id)}</td>
        <td>${escapeHtml(row.from)} → ${escapeHtml(row.to)}</td>
        <td><a href="#" data-open-msg="${escapeHtml(row.id)}">${escapeHtml(row.subject)}</a></td>
        <td>${escapeHtml(read)}</td>
        <td>${escapeHtml(row.createdAt)}</td>
        <td class="actions"><button data-reply="${escapeHtml(row.id)}">回信</button></td>
      </tr>`;
    })
    .join("");

  panel.innerHTML = `
    <div class="toolbar"><button id="new-msg" class="primary">写新信</button></div>
    <table>
      <thead><tr><th>id</th><th>from → to</th><th>subject</th><th>readBy</th><th>createdAt</th><th></th></tr></thead>
      <tbody>${rows || emptyRow(6, "收件箱是空的")}</tbody>
    </table>`;
}

function renderDocs() {
  const panel = $("panel-docs");
  if (!STATE.connected || !STATE.initialized) {
    panel.innerHTML = `<div class="empty">先连接并初始化一个项目目录。</div>`;
    return;
  }
  const rows = STATE.docs
    .map(
      (doc) => `<tr>
        <td><a href="#" data-open-doc="${escapeHtml(doc.name)}">${escapeHtml(doc.name)}</a></td>
        <td>${doc.size} B</td>
        <td>${escapeHtml(doc.mtime)}</td>
        <td class="actions"><button data-copy-doc="${escapeHtml(doc.name)}">复制路径</button></td>
      </tr>`
    )
    .join("");
  panel.innerHTML = `
    <div class="toolbar"><span class="muted">docs/ 只读 —— 写设计文档是分析师的职责。</span></div>
    <table>
      <thead><tr><th>文件名</th><th>大小</th><th>修改时间</th><th></th></tr></thead>
      <tbody>${rows || emptyRow(4, "docs/ 里还没有文档")}</tbody>
    </table>`;
}

function render() {
  for (const tab of ["tasks", "bugs", "inbox", "docs"]) {
    $("panel-" + tab).hidden = tab !== activeTab;
  }
  document.querySelectorAll("#tabs button").forEach((b) => {
    b.classList.toggle("active", b.dataset.tab === activeTab);
  });
  if (activeTab === "tasks") renderTasks();
  if (activeTab === "bugs") renderBugs();
  if (activeTab === "inbox") renderInbox();
  if (activeTab === "docs") renderDocs();
}

function findTask(id) { return STATE.tasks.find((t) => t.ok && t.id === id); }
function findBug(id) { return STATE.bugs.find((b) => b.ok && b.id === id); }
function findMessage(id) { return STATE.inbox.find((m) => m.ok && m.id === id); }

function drawer(html) {
  const el = $("drawer");
  el.innerHTML = html;
  el.hidden = false;
}
function closeDrawer() { $("drawer").hidden = true; $("drawer").innerHTML = ""; }

function options(list, current) {
  return list.map((v) => `<option value="${escapeHtml(v)}"${v === current ? " selected" : ""}>${escapeHtml(v)}</option>`).join("");
}

function openTask(id) {
  const task = findTask(id);
  if (!task) return;
  // 人类是外部来源：任何状态都能改成任何状态，所以这里列全部（含终态，可以重开）。
  // 「评估完成」不在下拉里 —— 它走上面那个放行端点，好让"放行"永远只有一条可审计通道。
  const statusOptions = options(
    [task.status, ...TASK_STATUSES.filter((s) => s !== "评估完成" && s !== task.status)],
    task.status
  );
  const notes = (task.notes || [])
    .slice()
    .reverse()
    .map((n) => `<li><time>${escapeHtml(n.at)} · ${escapeHtml(n.by)}</time><div>${escapeHtml(n.text)}</div></li>`)
    .join("");
  const bugLinks = (task.relatedBugs || []).length
    ? task.relatedBugs
        .map((b) => `<a href="#" data-goto-bug="${escapeHtml(b)}">${escapeHtml(b)}</a>`)
        .join("、")
    : "—";

  drawer(`
    <h2>${escapeHtml(task.id)} · ${escapeHtml(task.title)}</h2>
    <div class="drawer-actions">
      <button id="close-drawer">关闭</button>
      <button id="save-task" class="primary" data-id="${escapeHtml(task.id)}">保存</button>
    </div>
    <div class="field"><label>标题</label><input id="f-title" value="${escapeHtml(task.title)}"></div>
    <div class="field"><label>原始需求（detail）</label><textarea id="f-detail">${escapeHtml(task.detail)}</textarea></div>
    <div class="field"><label>优先级</label><select id="f-priority">${options(PRIORITIES, task.priority)}</select></div>
    <div class="field"><label>冲刺标识（sprint）</label><input id="f-sprint" value="${escapeHtml(task.sprint ?? "")}" placeholder="S-2026-09-19"></div>
    <div class="field"><label>状态</label><select id="f-status">${statusOptions}</select></div>
    <div class="field"><label>改状态的原因（改状态时必填；留空会自动填一个如实说明）</label><input id="f-note" placeholder="例如：设计文档已看过"></div>
    <div class="field"><label>source（只读）</label><input value="${escapeHtml(task.source)}" disabled></div>
    <fieldset>
      <legend>团队字段（契约里由分析师/质量测试维护，但你是外部来源，可以直接改）</legend>
      <div class="field"><label>designDoc</label><input id="f-designDoc" value="${escapeHtml(task.designDoc ?? "")}"></div>
      <div class="field"><label>owner</label><select id="f-owner"><option value="">（无）</option>${options(["analyst", "developer", "qa"], task.owner ?? "")}</select></div>
      <div class="field">
        <label>relatedBugs（逗号分隔 —— 点编号会跳到 Bug 标签页）</label>
        <div>${bugLinks}</div>
        <input id="f-relatedBugs" value="${escapeHtml((task.relatedBugs || []).join(", "))}">
      </div>
    </fieldset>
    <fieldset><legend>notes（只追加）</legend><ul class="notes">${notes || "<li>还没有记录</li>"}</ul></fieldset>
  `);
  $("drawer").dataset.expectedUpdatedAt = task.updatedAt;
  $("drawer").dataset.kind = "task";
}

function openBug(id) {
  const bug = findBug(id);
  if (!bug) return;
  // 同样没有转换白名单：所有状态都列出来，当前状态在最前并被选中。
  const target = [bug.status, ...BUG_STATUSES.filter((s) => s !== bug.status)];
  const notes = (bug.notes || [])
    .slice()
    .reverse()
    .map((n) => `<li><time>${escapeHtml(n.at)} · ${escapeHtml(n.by)}</time><div>${escapeHtml(n.text)}</div></li>`)
    .join("");
  drawer(`
    <h2>${escapeHtml(bug.id)} · ${escapeHtml(bug.title)}</h2>
    <div class="drawer-actions">
      <button id="close-drawer">关闭</button>
      <button id="save-bug" class="primary" data-id="${escapeHtml(bug.id)}">保存</button>
    </div>
    <div class="field"><label>标题</label><input id="f-title" value="${escapeHtml(bug.title)}"></div>
    <div class="field"><label>severity</label><select id="f-severity">${options(SEVERITIES, bug.severity)}</select></div>
    <div class="field"><label>status</label><select id="f-status">${options(target, bug.status)}</select></div>
    <div class="field"><label>改状态的原因（状态变化时必填）</label><input id="f-note"></div>
    <div class="field"><label>taskId</label><input id="f-taskId" value="${escapeHtml(bug.taskId ?? "")}"></div>
    <div class="field"><label>复现步骤</label><textarea id="f-steps">${escapeHtml(bug.steps)}</textarea></div>
    <div class="field"><label>期望行为</label><textarea id="f-expected">${escapeHtml(bug.expected)}</textarea></div>
    <div class="field"><label>实际行为</label><textarea id="f-actual">${escapeHtml(bug.actual)}</textarea></div>
    <div class="field"><label>env</label><input id="f-env" value="${escapeHtml(bug.env)}"></div>
    <fieldset><legend>notes（只追加）</legend><ul class="notes">${notes || "<li>还没有记录</li>"}</ul></fieldset>
  `);
  $("drawer").dataset.expectedUpdatedAt = bug.updatedAt;
  $("drawer").dataset.kind = "bug";
}

function openMessage(id) {
  const msg = findMessage(id);
  if (!msg) return;
  const refs = (msg.refs && msg.refs.docs) || [];
  drawer(`
    <h2>${escapeHtml(msg.id)} · ${escapeHtml(msg.subject)}</h2>
    <div class="drawer-actions">
      <button id="close-drawer">关闭</button>
      <button id="reply-from-drawer" data-id="${escapeHtml(msg.id)}">回信</button>
    </div>
    <div class="muted">${escapeHtml(msg.from)} → ${escapeHtml(msg.to)} · ${escapeHtml(msg.createdAt)}
      ${msg.inReplyTo ? " · 回复 " + escapeHtml(msg.inReplyTo) : ""}</div>
    <div class="md">${renderMarkdown(msg.body)}</div>
    ${refs.length ? `<div class="muted">引用文档：${refs.map(escapeHtml).join("、")}</div>` : ""}
  `);
  $("drawer").dataset.kind = "message";
}

function openDoc(name) {
  api("/api/docs/" + encodeURIComponent(name))
    .then((doc) => {
      drawer(`
        <h2>${escapeHtml(doc.name)}</h2>
        <div class="drawer-actions">
          <button id="close-drawer">关闭</button>
          <button data-copy-doc="${escapeHtml(doc.name)}">复制路径</button>
        </div>
        <div class="md">${renderMarkdown(doc.content)}</div>
      `);
      $("drawer").dataset.kind = "doc";
    })
    .catch((error) => toast(error.message, "error"));
}

function newTaskForm() {
  drawer(`
    <h2>新建任务</h2>
    <div class="drawer-actions">
      <button id="close-drawer">取消</button>
      <button id="create-task" class="primary">创建</button>
    </div>
    <div class="field"><label>标题（必填）</label><input id="f-title"></div>
    <div class="field"><label>source</label><select id="f-source">${options(["human", "issue", "bug", "internal"], "human")}</select></div>
    <div class="field"><label>原始需求（detail）</label><textarea id="f-detail"></textarea></div>
    <div class="field"><label>优先级</label><select id="f-priority">${options(PRIORITIES, "P2")}</select></div>
    <div class="muted">status 固定为 new —— 分析师接手后才会变。</div>
  `);
  $("drawer").dataset.kind = "new-task";
}

function newBugForm() {
  const taskOptions = STATE.tasks
    .filter((t) => t.ok)
    .map((t) => `<option value="${escapeHtml(t.id)}">${escapeHtml(t.id)} ${escapeHtml(t.title)}</option>`)
    .join("");
  drawer(`
    <h2>新建 Bug</h2>
    <div class="drawer-actions">
      <button id="close-drawer">取消</button>
      <button id="create-bug" class="primary">创建</button>
    </div>
    <div class="field"><label>标题（必填）</label><input id="f-title"></div>
    <div class="field"><label>severity</label><select id="f-severity">${options(SEVERITIES, "minor")}</select></div>
    <div class="field"><label>关联任务</label><select id="f-taskId"><option value="">（无关联）</option>${taskOptions}</select></div>
    <div class="field"><label>若为「无关联」，必须说明原因（写入 notes）</label><input id="f-note"></div>
    <div class="field"><label>复现步骤</label><textarea id="f-steps"></textarea></div>
    <div class="field"><label>期望行为</label><textarea id="f-expected"></textarea></div>
    <div class="field"><label>实际行为</label><textarea id="f-actual"></textarea></div>
    <div class="field"><label>env</label><input id="f-env"></div>
  `);
  $("drawer").dataset.kind = "new-bug";
}

function messageForm(prefill = {}) {
  drawer(`
    <h2>${prefill.inReplyTo ? "回信" : "写新信"}</h2>
    <div class="drawer-actions">
      <button id="close-drawer">取消</button>
      <button id="create-msg" class="primary">发送</button>
    </div>
    <div class="field"><label>收件人 to</label><select id="f-to">${options(["dsh", "analyst", "developer", "qa"], prefill.to || "dsh")}</select></div>
    <div class="field"><label>主题</label><input id="f-subject" value="${escapeHtml(prefill.subject || "")}"></div>
    <div class="field"><label>正文（markdown）</label><textarea id="f-body" style="min-height:180px"></textarea></div>
    <div class="muted">from 固定为 human${prefill.inReplyTo ? " · 回复 " + escapeHtml(prefill.inReplyTo) : ""}</div>
  `);
  $("drawer").dataset.kind = "new-message";
  $("drawer").dataset.inReplyTo = prefill.inReplyTo || "";
}

async function approveTask(id, skipEvaluation) {
  const task = findTask(id);
  if (!task) return;
  const hint = skipEvaluation
    ? `「${task.title}」还是 new，未经分析师评估。直接放行？会在 notes 里留下越闸记录。`
    : `确认把「${task.title}」放行为 评估完成？`;
  if (!confirm(hint)) return;
  try {
    await api(`/api/tasks/${encodeURIComponent(id)}/approve`, {
      method: "POST",
      body: JSON.stringify({}),
    });
    clearNotice();
    toast("已放行：" + id);
    await refresh(false);
    render();
  } catch (error) {
    toast(error.message, "error");
  }
}

async function rejectTask(id) {
  const task = findTask(id);
  if (!task) return;
  const note = prompt("驳回原因（必填，写入 notes）：");
  if (!note) return;
  try {
    await api(`/api/tasks/${encodeURIComponent(id)}`, {
      method: "PATCH",
      body: JSON.stringify({ status: "reject", note, expectedUpdatedAt: task.updatedAt }),
    });
    clearNotice();
    toast("已驳回：" + id);
    await refresh(false);
    render();
  } catch (error) {
    toast(error.message, "error");
  }
}

async function saveTask(id) {
  const task = findTask(id);
  if (!task) return;
  const status = $("f-status").value;
  let note = $("f-note").value.trim();
  // 改状态必须留原因（契约要求团队能看到为什么）。留空就自动填一个如实说明，
  // 既不挡路，notes 里也不会出现空白的状态变更。
  if (status !== task.status && !note) {
    note = `人类把状态从「${task.status}」改为「${status}」`;
  }
  const body = {
    title: $("f-title").value,
    detail: $("f-detail").value,
    priority: $("f-priority").value,
    sprint: $("f-sprint").value || null,
    status,
    note,
    // 已经没有任何确认门槛了，团队字段直接发，不必再做差异比较
    designDoc: $("f-designDoc").value || null,
    owner: $("f-owner").value || null,
    relatedBugs: $("f-relatedBugs").value
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean),
    expectedUpdatedAt: $("drawer").dataset.expectedUpdatedAt,
  };
  try {
    await api(`/api/tasks/${encodeURIComponent(id)}`, { method: "PATCH", body: JSON.stringify(body) });
    clearNotice();
    toast("已保存 " + id);
    closeDrawer();
    await refresh(false);
    render();
  } catch (error) {
    toast(error.message, "error");
    if (error.status === 409) {
      showNotice("这条记录已被牛棚成员改动，已刷新 —— 请核对后再保存");
      await refresh(false);
      render();
    }
  }
}

async function saveBug(id) {
  const bug = findBug(id);
  if (!bug) return;
  const status = $("f-status").value;
  let note = $("f-note").value.trim();
  if (status !== bug.status && !note) {
    note = `人类把状态从「${bug.status}」改为「${status}」`;
  }
  const body = {
    title: $("f-title").value,
    severity: $("f-severity").value,
    status,
    note,
    taskId: $("f-taskId").value || null,
    steps: $("f-steps").value,
    expected: $("f-expected").value,
    actual: $("f-actual").value,
    env: $("f-env").value,
    expectedUpdatedAt: $("drawer").dataset.expectedUpdatedAt,
  };
  try {
    await api(`/api/bugs/${encodeURIComponent(id)}`, { method: "PATCH", body: JSON.stringify(body) });
    clearNotice();
    toast("已保存 " + id);
    closeDrawer();
    await refresh(false);
    render();
  } catch (error) {
    toast(error.message, "error");
    if (error.status === 409) {
      showNotice("这条记录已被牛棚成员改动，已刷新 —— 请核对后再保存");
      await refresh(false);
      render();
    }
  }
}

async function createTask() {
  const title = $("f-title").value.trim();
  if (!title) { toast("标题不能为空", "warn"); return; }
  try {
    const created = await api("/api/tasks", {
      method: "POST",
      body: JSON.stringify({
        title,
        source: $("f-source").value,
        detail: $("f-detail").value,
        priority: $("f-priority").value,
      }),
    });
    toast("已创建 " + created.id);
    closeDrawer();
    await refresh(false);
    render();
  } catch (error) {
    toast(error.message, "error");
  }
}

async function createBug() {
  const title = $("f-title").value.trim();
  if (!title) { toast("标题不能为空", "warn"); return; }
  const taskId = $("f-taskId").value || null;
  if (taskId === null && !$("f-note").value.trim()) {
    toast("不关联任务时必须说明原因", "warn");
    return;
  }
  try {
    const created = await api("/api/bugs", {
      method: "POST",
      body: JSON.stringify({
        title,
        severity: $("f-severity").value,
        taskId,
        note: $("f-note").value,
        steps: $("f-steps").value,
        expected: $("f-expected").value,
        actual: $("f-actual").value,
        env: $("f-env").value,
      }),
    });
    toast("已创建 " + created.id);
    closeDrawer();
    await refresh(false);
    render();
  } catch (error) {
    toast(error.message, "error");
  }
}

async function createMessage() {
  const subject = $("f-subject").value.trim();
  const body = $("f-body").value.trim();
  if (!subject) { toast("主题不能为空", "warn"); return; }
  if (!body) { toast("正文不能为空", "warn"); return; }
  try {
    const inReplyTo = $("drawer").dataset.inReplyTo || null;
    const created = await api("/api/messages", {
      method: "POST",
      body: JSON.stringify({
        to: $("f-to").value,
        subject,
        body,
        inReplyTo,
      }),
    });
    toast("已发送 " + created.id);
    closeDrawer();
    await refresh(false);
    render();
  } catch (error) {
    toast(error.message, "error");
  }
}

function replyTo(id) {
  const msg = findMessage(id);
  if (!msg) return;
  const to = msg.from === "human" ? "dsh" : msg.from;
  messageForm({ to, subject: "Re: " + msg.subject, inReplyTo: msg.id });
}

function copyText(text) {
  navigator.clipboard.writeText(text).then(
    () => toast("已复制：" + text),
    () => toast("复制失败，请手工选择", "warn")
  );
}

document.addEventListener("click", (event) => {
  const el = event.target.closest("button, a");
  if (!el) return;
  const dataset = el.dataset || {};

  if (el.id === "close-drawer") { closeDrawer(); return; }
  if (el.id === "connect") { connect(); return; }
  if (el.id === "init") { initialise(); return; }
  if (el.id === "new-task") { newTaskForm(); return; }
  if (el.id === "new-bug") { newBugForm(); return; }
  if (el.id === "new-msg") { messageForm(); return; }
  if (el.id === "create-task") { createTask(); return; }
  if (el.id === "create-bug") { createBug(); return; }
  if (el.id === "create-msg") { createMessage(); return; }
  if (el.id === "save-task") { saveTask(dataset.id); return; }
  if (el.id === "save-bug") { saveBug(dataset.id); return; }
  if (el.id === "reply-from-drawer") { replyTo(dataset.id); return; }

  if (dataset.tab) { activeTab = dataset.tab; render(); return; }
  if (dataset.filter !== undefined && el.classList.contains("filter")) {
    taskFilter = dataset.filter; renderTasks(); return;
  }
  if (dataset.bugFilter !== undefined && el.classList.contains("filter")) {
    bugFilter = dataset.bugFilter; renderBugs(); return;
  }
  if (dataset.severityFilter !== undefined && el.classList.contains("filter")) {
    bugSeverityFilter = dataset.severityFilter; renderBugs(); return;
  }
  if (dataset.gotoBug) {
    event.preventDefault();
    activeTab = "bugs";
    render();
    openBug(dataset.gotoBug);
    return;
  }
  if (dataset.openTask) { event.preventDefault(); openTask(dataset.openTask); return; }
  if (dataset.openBug) { event.preventDefault(); openBug(dataset.openBug); return; }
  if (dataset.openMsg) { event.preventDefault(); openMessage(dataset.openMsg); return; }
  if (dataset.openDoc) { event.preventDefault(); openDoc(dataset.openDoc); return; }
  if (dataset.approve) { approveTask(dataset.approve, false); return; }
  if (dataset.approveSkip) { approveTask(dataset.approveSkip, true); return; }
  if (dataset.reject) { rejectTask(dataset.reject); return; }
  if (dataset.reply) { replyTo(dataset.reply); return; }
  if (dataset.copyDoc) {
    copyText((STATE.root || "").replace(/[\\/]+$/, "") + "\\.niupeng\\docs\\" + dataset.copyDoc);
    return;
  }
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") closeDrawer();
  if (event.key === "Enter" && el_isRoot(event.target)) connect();
});

function el_isRoot(target) { return target && target.id === "root"; }

function boot() {
  const saved = localStorage.getItem("niupengBoard.root");
  if (saved) $("root").value = saved;
  refresh(true).then(() => {
    if (!STATE.connected && saved) connect();
  });
  setInterval(() => refresh(true), 5000);
}

boot();
