"""文件系统层：把「一个项目目录」变成读写记录的操作。

本模块不知道 HTTP 存在。
术语（严格遵循设计文档 §1.1）：`root` / `project_dir` 一律指**项目目录**，
`.niupeng/` 是它下面存放数据的子目录。
"""

from __future__ import annotations

import difflib
import json
import os
import re
import threading
from dataclasses import dataclass
from datetime import datetime
from functools import cache
from pathlib import Path

from pydantic import ValidationError

from .models import (
    Bug,
    Message,
    Priority,
    Recipient,
    Severity,
    Task,
    TaskSource,
    now_iso,
    record_to_dict,
)

STORE_DIRNAME = ".niupeng"
SUBDIRS = ("tasks", "bugs", "inbox", "docs")

ID_PATTERNS = {
    "tasks": re.compile(r"^T-\d{4}$"),
    "bugs": re.compile(r"^B-\d{4}$"),
    "inbox": re.compile(r"^M-\d{4}$"),
}
ID_PREFIX = {"tasks": "T-", "bugs": "B-", "inbox": "M-"}
MODEL_BY_KIND = {"tasks": Task, "bugs": Bug, "inbox": Message}

MAX_ID_ATTEMPTS = 50


class StoreError(Exception):
    """基类。"""


class Invalid(StoreError):
    """请求本身不合法（→ 400）。"""


class NotFound(StoreError):
    """记录不存在（→ 404）。"""


class Conflict(StoreError):
    """当前状态不允许这个操作（→ 409）。"""


@dataclass(frozen=True)
class RootInfo:
    root: Path
    connected: bool
    initialized: bool


def store_dir(project_dir: Path) -> Path:
    return Path(project_dir) / STORE_DIRNAME


def _suggest_similar_directories(target: Path, limit: int = 5) -> list[str]:
    """给「目录不存在」提供拼写建议：在父目录里找名字相近的目录。

    这是人类最容易撞上的一个错误 —— 项目名打错一个字（牛马 / 牛棚），
    只报「不存在」的话人得自己去翻目录，明明信息就在手边。
    """
    parent = target.parent
    if not parent.is_dir():
        return []
    names = [entry.name for entry in parent.iterdir() if entry.is_dir()]
    if not names:
        return []
    close = difflib.get_close_matches(target.name, names, n=limit, cutoff=0.4)
    # 前缀相近的也算（edit distance 对长名字不敏感的情况）
    wanted = target.name.lower()
    for name in names:
        if name in close:
            continue
        lowered = name.lower()
        if wanted and lowered.startswith(wanted[: max(2, len(wanted) // 2)]):
            close.append(name)
        if len(close) >= limit:
            break
    return close[:limit]


def open_root(project_dir: Path) -> RootInfo:
    """校验路径是已存在的目录，并报告是否已初始化。"""
    p = Path(project_dir)
    if not p.exists():
        message = f"项目目录不存在：{p}"
        hints = _suggest_similar_directories(p)
        if hints:
            message += f"。你是不是想找：{'、'.join(hints)}？"
        elif not p.parent.is_dir():
            message += f"（上级目录 {p.parent} 也不存在）"
        raise Invalid(message)
    if not p.is_dir():
        raise Invalid(f"项目目录不是一个目录：{p}")
    base = store_dir(p)
    initialized = all((base / name).is_dir() for name in SUBDIRS)
    return RootInfo(root=p, connected=True, initialized=initialized)


@cache
def _readme_template() -> str:
    asset = Path(__file__).parent / "assets" / "store-README.md"
    return asset.read_text(encoding="utf-8")


def init_root(project_dir: Path) -> RootInfo:
    """幂等建骨架。已存在的文件绝不覆盖。"""
    info = open_root(project_dir)
    base = store_dir(info.root)
    # .niupeng 存在但是个文件时，mkdir 会抛裸 FileExistsError → POST /api/init 变 500，
    # 而 GET /api/state 同时还报告 initialized=false，界面会引导用户去点这个必然 500 的按钮。
    if base.exists() and not base.is_dir():
        raise Invalid(f"{STORE_DIRNAME} 已存在但不是目录：{base}")
    base.mkdir(exist_ok=True)
    for name in SUBDIRS:
        sub = base / name
        if sub.exists() and not sub.is_dir():
            raise Invalid(f".niupeng/{name} 已存在但不是目录：{sub}")
        sub.mkdir(exist_ok=True)
        keep = sub / ".gitkeep"
        if not keep.exists():
            keep.write_text("", encoding="utf-8")
    readme = base / "README.md"
    if not readme.exists():
        readme.write_text(_readme_template(), encoding="utf-8")
    return open_root(info.root)


def _require_initialized(project_dir: Path) -> RootInfo:
    info = open_root(project_dir)
    if not info.initialized:
        raise Conflict("数据目录尚未初始化，请先初始化项目目录下的 .niupeng/")
    return info


def _record_dir(project_dir: Path, kind: str) -> Path:
    if kind not in ID_PATTERNS:
        raise Invalid(f"未知的记录类型：{kind}")
    return store_dir(Path(project_dir)) / kind


def _require_id(kind: str, record_id: str) -> None:
    pattern = ID_PATTERNS.get(kind)
    if pattern is None:
        raise Invalid(f"未知的记录类型：{kind}")
    if not pattern.fullmatch(record_id):
        raise Invalid(f"记录编号格式非法：{record_id!r}")


def _iso_from_timestamp(ts: float) -> str:
    return datetime.fromtimestamp(ts).astimezone().isoformat(timespec="seconds")


def _read_json(path: Path) -> object:
    """读并解析一个 JSON 文件，重试一次以应对 agent 正在写的瞬间。

    注意捕获 `ValueError` 而不是 `json.JSONDecodeError`：`UnicodeDecodeError` 也是
    `ValueError` 的子类却不是 `OSError`，中文 Windows 上一个 GBK / UTF-16 编码的记录文件
    必须走宽容路径，不能把整个列表带崩。
    """
    last: Exception | None = None
    for attempt in (1, 2):
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            last = exc
            if attempt == 1:
                continue
    raise last if last is not None else OSError(f"无法读取：{path}")


def _load_record(path: Path, kind: str) -> dict:
    """宽容读取：损坏的记录变成 error row，不让整个列表读取崩掉。"""
    try:
        raw = _read_json(path)
    except (OSError, ValueError) as exc:
        return {"ok": False, "file": path.name, "error": f"无法解析：{exc}"}
    if not isinstance(raw, dict):
        # 文件内容可能是字面量 null / 数组 / 字符串。
        # 不能拿 `raw is None` 当"解析失败"的哨兵 —— 那会把合法的 null 误报成解析失败。
        return {
            "ok": False,
            "file": path.name,
            "error": f"记录必须是 JSON 对象，实际是 {type(raw).__name__}",
        }
    try:
        record = MODEL_BY_KIND[kind].model_validate(raw)
    except ValidationError as exc:
        kinds = "、".join(sorted({str(e["loc"][0]) for e in exc.errors() if e["loc"]}))
        return {
            "ok": False,
            "file": path.name,
            "error": f"字段不符合契约：{kinds or '未知字段'}",
        }
    if record.id != path.stem:
        return {
            "ok": False,
            "file": path.name,
            "error": f"文件名与记录 id 不一致（id={record.id}）",
        }
    return {"ok": True, **record_to_dict(record)}


def _load_for_update(path: Path, kind: str) -> tuple[dict, dict]:
    """写入路径专用：返回 `(磁盘上的原始 dict, 校验后的 dump)`，任何问题都抛 `Conflict`。

    与 `_load_record` 的分工：那个服务于"列出一堆记录、坏了就标红"的容错场景，
    这个服务于"我要改这一条，坏了就别动它"的严格场景。两份代码相似但契约不同。
    """
    try:
        raw = _read_json(path)
    except (OSError, ValueError) as exc:
        raise Conflict(f"记录文件损坏，需手工修复：{path.name}（{exc}）") from exc
    if not isinstance(raw, dict):
        raise Conflict(f"记录文件不是 JSON 对象：{path.name}")
    try:
        record = MODEL_BY_KIND[kind].model_validate(raw)
    except ValidationError as exc:
        raise Conflict(f"记录文件字段不符合契约，需手工修复：{path.name}") from exc
    if record.id != path.stem:
        raise Conflict(f"文件名与记录 id 不一致：{path.name}")
    return raw, record_to_dict(record)


def list_records(project_dir: Path, kind: str) -> list[dict]:
    info = _require_initialized(project_dir)
    directory = _record_dir(info.root, kind)
    return [_load_record(path, kind) for path in sorted(directory.glob("*.json"))]


def read_record(project_dir: Path, kind: str, record_id: str) -> dict:
    _require_id(kind, record_id)
    info = _require_initialized(project_dir)
    path = _record_dir(info.root, kind) / f"{record_id}.json"
    if not path.is_file():
        raise NotFound(f"记录不存在：{record_id}")
    _, dumped = _load_for_update(path, kind)
    return {"ok": True, **dumped}


def _atomic_write_json(path: Path, data: dict) -> None:
    """先写临时文件再 os.replace，避免读到半截 JSON。

    临时文件名带上 pid 与线程 id：两个写入者同时改同一条记录时，
    共用一个 .tmp 名字会互相截断，反而把坏内容 replace 进去。
    `newline` 显式指定为 LF，让 Windows 上落盘的行尾与团队成员写的文件一致。
    """
    tmp = path.with_name(f"{path.name}.{os.getpid()}.{threading.get_ident()}.tmp")
    try:
        tmp.write_text(
            json.dumps(data, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
            newline="\n",
        )
        os.replace(tmp, path)
    except OSError:
        # 替换失败（例如 Windows 上目标正被占用）时不要在被监视的数据目录里留下垃圾
        tmp.unlink(missing_ok=True)
        raise


def _next_id(project_dir: Path, kind: str) -> str:
    """扫描目录取当前最大编号 +1。不要凭记忆。"""
    directory = _record_dir(project_dir, kind)
    pattern = ID_PATTERNS[kind]
    biggest = 0
    for path in directory.glob("*.json"):
        stem = path.stem
        if pattern.fullmatch(stem):
            biggest = max(biggest, int(stem[2:]))
    return f"{ID_PREFIX[kind]}{biggest + 1:04d}"


def _new_record_payload(kind: str, **fields) -> dict:
    stamp = now_iso()
    if kind == "tasks":
        return {
            "title": fields["title"],
            "source": fields["source"],
            "detail": fields.get("detail") or "",
            "status": "new",
            "priority": fields.get("priority") or "P2",
            "sprint": None,
            "designDoc": None,
            "relatedBugs": [],
            "owner": None,
            "notes": [],
            "createdAt": stamp,
            "updatedAt": stamp,
        }
    if kind == "bugs":
        return {
            "taskId": fields.get("taskId"),
            "title": fields["title"],
            "severity": fields["severity"],
            "status": "new",
            "steps": fields.get("steps") or "",
            "expected": fields.get("expected") or "",
            "actual": fields.get("actual") or "",
            "env": fields.get("env") or "",
            "notes": fields.get("notes") or [],
            "createdAt": stamp,
            "updatedAt": stamp,
        }
    if kind == "inbox":
        return {
            "from": "human",
            "to": fields["to"],
            "subject": fields["subject"],
            "body": fields["body"],
            "refs": fields.get("refs") or {"tasks": [], "bugs": [], "docs": []},
            "inReplyTo": fields.get("inReplyTo"),
            "createdAt": stamp,
            "readBy": [],
        }
    raise Invalid(f"未知的记录类型：{kind}")


def _create_record(project_dir: Path, kind: str, payload: dict) -> dict:
    """分配编号 → 独占创建 → 落盘。编号被并发占用则顺延重试。"""
    info = _require_initialized(project_dir)
    directory = _record_dir(info.root, kind)
    model = MODEL_BY_KIND[kind]
    for _ in range(MAX_ID_ATTEMPTS):
        record_id = _next_id(info.root, kind)
        candidate = {**payload, "id": record_id}
        path = directory / f"{record_id}.json"
        try:
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            # 有人抢先占了这个编号，重算一个再来
            continue
        validated = model.model_validate(candidate)
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(
                json.dumps(record_to_dict(validated), ensure_ascii=False, indent=2) + "\n"
            )
        return {"ok": True, **record_to_dict(validated)}
    raise StoreError(f"编号分配失败：连续 {MAX_ID_ATTEMPTS} 次都撞号")


def create_task(
    project_dir: Path,
    *,
    title: str,
    source: TaskSource | str,
    detail: str | None = None,
    priority: Priority | str | None = None,
) -> dict:
    """三个 create_* 都用显式关键字参数。拼错字段名会当场 TypeError，
    而不是落进 `**fields` 里、等到 `_new_record_payload` 取 key 时才炸成 500。"""
    return _create_record(
        project_dir,
        "tasks",
        _new_record_payload(
            "tasks", title=title, source=source, detail=detail, priority=priority
        ),
    )


def create_bug(
    project_dir: Path,
    *,
    title: str,
    severity: Severity | str,
    taskId: str | None = None,
    steps: str | None = None,
    expected: str | None = None,
    actual: str | None = None,
    env: str | None = None,
    notes: list[dict] | None = None,
) -> dict:
    return _create_record(
        project_dir,
        "bugs",
        _new_record_payload(
            "bugs",
            title=title,
            severity=severity,
            taskId=taskId,
            steps=steps,
            expected=expected,
            actual=actual,
            env=env,
            notes=notes,
        ),
    )


def create_message(
    project_dir: Path,
    *,
    to: Recipient | str,
    subject: str,
    body: str,
    refs: dict | None = None,
    inReplyTo: str | None = None,
) -> dict:
    return _create_record(
        project_dir,
        "inbox",
        _new_record_payload(
            "inbox", to=to, subject=subject, body=body, refs=refs, inReplyTo=inReplyTo
        ),
    )


def update_record(
    project_dir: Path,
    kind: str,
    record_id: str,
    patch: dict,
    *,
    expected_updated_at: str | None,
) -> dict:
    """读 → 校验乐观锁 → 合并 → 校验 → 原子覆写这一个文件。

    只写目标文件，绝不整目录重写。

    已知限制：契约要求 `updatedAt` 是秒级 ISO 8601，所以同一秒内的两次改动
    无法被这把锁区分。详情抽屉通常开着数秒到数分钟，这个窗口可以接受 ——
    它是防误覆盖的安全网，不是并发正确性保证。
    """
    _require_id(kind, record_id)
    info = _require_initialized(project_dir)
    path = _record_dir(info.root, kind) / f"{record_id}.json"
    if not path.is_file():
        raise NotFound(f"记录不存在：{record_id}")

    raw, current = _load_for_update(path, kind)
    if expected_updated_at is not None and current["updatedAt"] != expected_updated_at:
        raise Conflict("这条记录已被牛棚成员改动，请刷新后重试")

    # 在**磁盘原始 JSON** 上做合并，而不是在模型 dump 上：
    # 契约字段集之外的内容（别的工具或未来版本加的字段）必须原样保留，
    # 否则一次 PATCH 就会把它们静默删掉。
    merged = dict(raw)
    merged.update(patch)
    merged["id"] = record_id
    merged["updatedAt"] = now_iso()

    validated = MODEL_BY_KIND[kind].model_validate(merged)
    _atomic_write_json(path, merged)
    return {"ok": True, **record_to_dict(validated)}


def list_docs(project_dir: Path) -> list[dict]:
    info = open_root(project_dir)
    directory = store_dir(info.root) / "docs"
    if not directory.is_dir():
        return []
    out = []
    for path in sorted(directory.glob("*.md")):
        stat = path.stat()
        out.append(
            {
                "name": path.name,
                "size": stat.st_size,
                "mtime": _iso_from_timestamp(stat.st_mtime),
            }
        )
    return out


def read_doc(project_dir: Path, name: str) -> dict:
    if not name or name in {".", ".."}:
        raise Invalid("文档名非法")
    if "/" in name or "\\" in name or ".." in name:
        raise Invalid("文档名非法")
    if not name.lower().endswith(".md"):
        raise Invalid("只支持读取 .md 文档")
    info = open_root(project_dir)
    directory = (store_dir(info.root) / "docs").resolve()
    target = (directory / name).resolve()
    if directory not in target.parents:
        raise Invalid("文档路径越界")
    if not target.is_file():
        raise NotFound(f"文档不存在：{name}")
    return {"name": name, "content": target.read_text(encoding="utf-8")}
