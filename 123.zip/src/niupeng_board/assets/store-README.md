# `.niupeng` —— 牛棚团队的数据目录

这个目录是牛棚（三人软件开发小团队）的唯一事实来源。**一条记录一个 JSON 文件**，
这样三名成员并发开工时不会互相覆盖。

```
.niupeng/
  README.md     ← 本文件
  tasks/        任务列表    T-0001.json, T-0002.json ...
  bugs/         bug 列表    B-0001.json ...
  inbox/        站内信      M-0001.json ...
  docs/         需求说明 / 功能设计 / 开发执行计划
```

## 给人看的用法（你是外部来源）

1. **加需求**：在 `tasks/` 里新建 `T-XXXX.json`（四位序号取当前最大值 +1），照下面模板填，
   `status` 写 `"new"`。
2. **放行开发**：把某条任务的 `status` 从 `"需求评估中"` 改成 `"评估完成"`。
   这是**唯一**能让软件开发动手的方式 —— 团队成员自己不许写这个状态。
3. **回信**：在 `inbox/` 里新建 `M-XXXX.json`，`from` 写 `"human"`、`to` 写 `"dsh"`，
   用 `inReplyTo` 指回你回复的那条消息。棚主和分析师会在下一轮读取并处理。
4. **看进度**：直接看 `tasks/` 与 `bugs/` 里的 `status` 字段，或问棚主让它汇总。

## 任务模板 `tasks/T-0001.json`

```json
{
  "id": "T-0001",
  "title": "一句话标题",
  "source": "human",
  "detail": "原始需求原文、链接或 issue 号",
  "status": "new",
  "priority": "P2",
  "sprint": null,
  "designDoc": null,
  "relatedBugs": [],
  "owner": null,
  "notes": [],
  "createdAt": "2026-09-19T10:00:00+08:00",
  "updatedAt": "2026-09-19T10:00:00+08:00"
}
```

## 任务状态

`new` →（分析师）`需求评估中` →（**你**）`评估完成` →（开发）`开发中` →（开发）`开发完成`
→（测试）`验证中` → `已完成`；不合理的需求由分析师置为 `reject`。

`priority` 取 `P0` / `P1` / `P2` / `P3`；`sprint` 写冲刺标识（如 `S-2026-09-19`）或保持 `null`。

## bug 模板 `bugs/B-0001.json`

```json
{
  "id": "B-0001",
  "taskId": "T-0001",
  "title": "一句话描述现象",
  "severity": "major",
  "status": "new",
  "steps": "复现步骤",
  "expected": "期望行为",
  "actual": "实际行为",
  "env": "分支 / 版本 / 平台",
  "notes": [],
  "createdAt": "2026-09-19T10:00:00+08:00",
  "updatedAt": "2026-09-19T10:00:00+08:00"
}
```

`severity` 取 `blocker` / `major` / `minor` / `trivial`；
`status` 取 `new` / `已确认` / `修复中` / `待验证` / `已关闭` / `reject`。

## 站内信模板 `inbox/M-0001.json`

```json
{
  "id": "M-0001",
  "from": "human",
  "to": "dsh",
  "subject": "主题",
  "body": "markdown 正文",
  "refs": { "tasks": ["T-0001"], "bugs": [], "docs": [] },
  "inReplyTo": "M-0000",
  "createdAt": "2026-09-19T10:00:00+08:00",
  "readBy": []
}
```

`to: "dsh"` 表示发给整个牛棚。人类的消息 `from` 写 `"human"`。

## 状态字符串必须逐字一致

`new`、`需求评估中`、`评估完成`、`开发中`、`开发完成`、`验证中`、`已完成`、`reject`。
大小写、空格、中英文都不要改写 —— 这些字符串就是团队成员判断下一步的依据。
