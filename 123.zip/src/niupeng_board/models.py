"""牛棚数据契约的形状：枚举常量与 pydantic 模型。

本模块不碰文件系统，也不碰 HTTP。
契约要求状态字符串逐字一致 —— 中文值就是值本身，不是显示标签，
因此这里全部以字面量原样书写，不得翻译或替换同义词。
"""

from __future__ import annotations

import re
from datetime import datetime
from enum import StrEnum
from typing import Annotated

from pydantic import AfterValidator, BaseModel, ConfigDict, Field


class TaskStatus(StrEnum):
    NEW = "new"
    ANALYZING = "需求评估中"
    APPROVED = "评估完成"
    DEVELOPING = "开发中"
    DEVELOPED = "开发完成"
    VERIFYING = "验证中"
    DONE = "已完成"
    REJECT = "reject"


class BugStatus(StrEnum):
    NEW = "new"
    CONFIRMED = "已确认"
    FIXING = "修复中"
    TO_VERIFY = "待验证"
    CLOSED = "已关闭"
    REJECT = "reject"


class Severity(StrEnum):
    BLOCKER = "blocker"
    MAJOR = "major"
    MINOR = "minor"
    TRIVIAL = "trivial"


class Priority(StrEnum):
    P0 = "P0"
    P1 = "P1"
    P2 = "P2"
    P3 = "P3"


class TaskSource(StrEnum):
    HUMAN = "human"
    ISSUE = "issue"
    BUG = "bug"
    INTERNAL = "internal"


class Owner(StrEnum):
    """任务 owner。契约里第 4 个取值是 null，在本模型里用 None 表示。"""

    ANALYST = "analyst"
    DEVELOPER = "developer"
    QA = "qa"


class Actor(StrEnum):
    """站内信 `from` 的取值域，同时也是 `notes.by` 的取值域。"""

    HUMAN = "human"
    ANALYST = "analyst"
    DEVELOPER = "developer"
    QA = "qa"
    LEAD = "lead"


class Recipient(StrEnum):
    """站内信 `to` 的取值域。`dsh` 表示发给整个牛棚。"""

    DSH = "dsh"
    HUMAN = "human"
    ANALYST = "analyst"
    DEVELOPER = "developer"
    QA = "qa"


ISO_STAMP = re.compile(
    r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:[+-]\d{2}:\d{2}|Z)$"
)


def _check_iso_stamp(value: str) -> str:
    if not ISO_STAMP.fullmatch(value):
        raise ValueError(
            "时间必须是带时区偏移的 ISO 8601，例如 2026-09-19T10:00:00+08:00"
            f"（收到 {value!r}）"
        )
    return value


#: 带时区偏移的 ISO 8601 时间戳。契约 §3.3 要求所有时间都用这个形状。
#: 没有这层校验的话，createdAt="昨天下午" 会被当成健康记录放过去。
IsoStamp = Annotated[str, AfterValidator(_check_iso_stamp)]


def now_iso() -> str:
    """本地时间 ISO 8601 带时区偏移，例如 2026-09-19T10:00:00+08:00。"""
    return datetime.now().astimezone().isoformat(timespec="seconds")


class Note(BaseModel):
    """任务与 bug 共用的 notes 元素。只追加，永不整体替换。"""

    at: IsoStamp
    by: Actor
    text: str


class Task(BaseModel):
    id: str
    title: str
    source: TaskSource
    detail: str = ""
    status: TaskStatus
    priority: Priority = Priority.P2
    sprint: str | None = None
    designDoc: str | None = None
    relatedBugs: list[str] = Field(default_factory=list)
    owner: Owner | None = None
    notes: list[Note] = Field(default_factory=list)
    createdAt: IsoStamp
    updatedAt: IsoStamp


class Bug(BaseModel):
    id: str
    taskId: str | None = None
    title: str
    severity: Severity
    status: BugStatus = BugStatus.NEW
    steps: str = ""
    expected: str = ""
    actual: str = ""
    env: str = ""
    notes: list[Note] = Field(default_factory=list)
    createdAt: IsoStamp
    updatedAt: IsoStamp


class MessageRefs(BaseModel):
    tasks: list[str] = Field(default_factory=list)
    bugs: list[str] = Field(default_factory=list)
    docs: list[str] = Field(default_factory=list)


class Message(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    id: str
    from_: Actor = Field(alias="from")
    to: Recipient
    subject: str
    body: str
    refs: MessageRefs = Field(default_factory=MessageRefs)
    inReplyTo: str | None = None
    createdAt: IsoStamp
    # readBy 是团队成员读后签名的位置，本工具不代人类签名，因此用宽松的 str 列表，
    # 避免一个不认识的名字把整条记录判成损坏。
    readBy: list[str] = Field(default_factory=list)


def record_to_dict(record: Task | Bug | Message) -> dict:
    """序列化成磁盘上的形状。必须 by_alias=True，否则 Message.from 会写成 from_。"""
    return record.model_dump(mode="json", by_alias=True)
