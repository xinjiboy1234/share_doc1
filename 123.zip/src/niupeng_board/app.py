"""HTTP 层：把 store 的能力暴露成 JSON API，并做请求级校验与错误映射。

保持薄 —— 业务规则只有「请求白名单」与「状态转换守卫」两类，
其余一律下沉到 store.py。

校验分层（设计文档 §6）：
- pydantic 管的（枚举非法、类型错误、缺必填字段）→ 422
- 业务语义管的（id 格式、跨记录引用、路径越界、状态机、乐观锁）→ 400 / 409，永不 422
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict
from starlette.exceptions import HTTPException as StarletteHTTPException

from . import store
from .models import (
    BugStatus,
    MessageRefs,
    Owner,
    Priority,
    Recipient,
    Severity,
    TaskSource,
    TaskStatus,
    now_iso,
)

STATIC_DIR = Path(__file__).parent / "static"
CONFIG_PATH = Path.home() / ".niupeng-board.json"
DEFAULT_PORT = 8765

TERMINAL_TASK_STATUSES = {TaskStatus.DONE, TaskStatus.REJECT}


# --------------------------------------------------------------------------
# 请求模型。全部声明在模块级：白名单就是模型字段本身，
# extra="allow" 会把「未声明」的字段收进 model_extra，于是只读字段可以被 400 拒掉。
# --------------------------------------------------------------------------


class RootBody(BaseModel):
    path: str


class TaskCreate(BaseModel):
    model_config = ConfigDict(extra="allow")
    title: str
    source: TaskSource
    detail: str | None = None
    priority: Priority | None = None


class TaskPatch(BaseModel):
    model_config = ConfigDict(extra="allow")
    title: str | None = None
    detail: str | None = None
    priority: Priority | None = None
    sprint: str | None = None
    designDoc: str | None = None
    owner: Owner | None = None
    relatedBugs: list[str] | None = None
    status: TaskStatus | None = None
    note: str | None = None
    expectedUpdatedAt: str | None = None


class ApproveBody(BaseModel):
    model_config = ConfigDict(extra="allow")
    priority: Priority | None = None
    sprint: str | None = None
    note: str | None = None


class BugCreate(BaseModel):
    model_config = ConfigDict(extra="allow")
    title: str
    severity: Severity
    taskId: str | None = None
    steps: str | None = None
    expected: str | None = None
    actual: str | None = None
    env: str | None = None
    note: str | None = None


class BugPatch(BaseModel):
    model_config = ConfigDict(extra="allow")
    title: str | None = None
    severity: Severity | None = None
    steps: str | None = None
    expected: str | None = None
    actual: str | None = None
    env: str | None = None
    taskId: str | None = None
    status: BugStatus | None = None
    note: str | None = None
    expectedUpdatedAt: str | None = None


class MessageCreate(BaseModel):
    model_config = ConfigDict(extra="allow")
    to: Recipient
    subject: str
    body: str
    # 用 MessageRefs 而不是裸 dict：非法形状（例如 {"tasks": "x"}）应该在请求校验阶段
    # 变成 422，而不是漏进 store 里抛 ValidationError 变成 500。
    refs: MessageRefs | None = None
    inReplyTo: str | None = None


def _load_config_root() -> Path | None:
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    root = data.get("root")
    return Path(root) if isinstance(root, str) and root else None


def _save_config_root(root: Path) -> None:
    try:
        CONFIG_PATH.write_text(
            json.dumps({"root": str(root)}, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    except OSError:
        # 记不住上次的目录不是致命错误
        pass


def _empty_state(root: Path | None, *, connected: bool) -> dict:
    return {
        "root": str(root) if root else None,
        "connected": connected,
        "initialized": False,
        "counts": {"tasks": 0, "bugs": 0, "inbox": 0, "docs": 0},
        "tasks": [],
        "bugs": [],
        "inbox": [],
        "docs": [],
    }


def create_app(root: Path | None = None) -> FastAPI:
    app = FastAPI(title="niupeng-board")
    app.state.root = root

    @app.exception_handler(store.Invalid)
    async def _invalid(_: Request, exc: store.Invalid) -> JSONResponse:
        return JSONResponse(status_code=400, content={"error": str(exc)})

    @app.exception_handler(store.NotFound)
    async def _not_found(_: Request, exc: store.NotFound) -> JSONResponse:
        return JSONResponse(status_code=404, content={"error": str(exc)})

    @app.exception_handler(store.Conflict)
    async def _conflict(_: Request, exc: store.Conflict) -> JSONResponse:
        return JSONResponse(status_code=409, content={"error": str(exc)})

    @app.exception_handler(store.StoreError)
    async def _store_error(_: Request, exc: store.StoreError) -> JSONResponse:
        return JSONResponse(status_code=500, content={"error": str(exc)})

    @app.exception_handler(StarletteHTTPException)
    async def _http_exception(_: Request, exc: StarletteHTTPException) -> JSONResponse:
        # FastAPI 默认把 HTTPException 渲染成 {"detail": ...}。
        # 设计文档 §6 要求全站统一 {"error": ...}（前端 api() 也只读 payload.error），
        # 所以这里覆盖默认 handler。
        return JSONResponse(
            status_code=exc.status_code,
            content={"error": str(exc.detail)},
            headers=getattr(exc, "headers", None),
        )

    def current_root() -> Path:
        value = app.state.root
        if value is None:
            raise store.Conflict("尚未设置项目目录")
        return value

    def build_state(r: Path) -> dict:
        try:
            info = store.open_root(r)
        except store.Invalid:
            return _empty_state(r, connected=False)
        if not info.initialized:
            return _empty_state(r, connected=True)
        tasks = store.list_records(r, "tasks")
        bugs = store.list_records(r, "bugs")
        inbox = store.list_records(r, "inbox")
        docs = store.list_docs(r)
        return {
            "root": str(info.root),
            "connected": True,
            "initialized": True,
            "counts": {
                "tasks": len(tasks),
                "bugs": len(bugs),
                "inbox": len(inbox),
                "docs": len(docs),
            },
            "tasks": tasks,
            "bugs": bugs,
            "inbox": inbox,
            "docs": docs,
        }

    # ---------------- 守卫 ----------------
    #
    # 只剩两条，而且都不是用来限制人类的：
    # 1. `reject_unknown_keys` —— 只读字段（id / createdAt / updatedAt / source / from / notes）不可改
    # 2. `require_note` —— 契约要求每次改状态都在 notes 留下原因，团队成员才看得见
    #
    # 这里**故意没有**状态转换白名单。人类就是「外部来源」，任何状态都可以改成任何状态。

    def reject_unknown_keys(body: BaseModel, where: str) -> None:
        extras = set(body.model_extra or {})
        if extras:
            raise HTTPException(
                status_code=400,
                detail=f"{where} 不允许这些字段：{'、'.join(sorted(extras))}",
            )

    def require_note(note: str | None) -> str:
        text = (note or "").strip()
        if not text:
            raise HTTPException(status_code=400, detail="改状态必须填写原因（note）")
        return text

    def append_note(current: dict, text: str) -> list[dict]:
        return list(current.get("notes") or []) + [
            {"at": now_iso(), "by": "human", "text": text}
        ]

    # ---------------- 配置与状态 ----------------

    @app.post("/api/root")
    def set_root(body: RootBody) -> dict:
        info = store.open_root(Path(body.path))
        app.state.root = info.root
        _save_config_root(info.root)
        return build_state(info.root)

    @app.get("/api/state")
    def get_state() -> dict:
        return build_state(current_root())

    @app.post("/api/init")
    def init_store() -> dict:
        info = store.init_root(current_root())
        return build_state(info.root)

    # ---------------- 任务 ----------------

    @app.post("/api/tasks")
    def create_task(body: TaskCreate) -> dict:
        reject_unknown_keys(body, "POST /api/tasks")
        return store.create_task(
            current_root(),
            title=body.title,
            source=body.source,
            detail=body.detail,
            priority=body.priority,
        )

    @app.patch("/api/tasks/{task_id}")
    def patch_task(task_id: str, body: TaskPatch) -> dict:
        reject_unknown_keys(body, "PATCH /api/tasks/{id}")
        root = current_root()
        current = store.read_record(root, "tasks", task_id)

        patch: dict = {}
        for key, value in body.model_dump(exclude_unset=True).items():
            if key in {"note", "expectedUpdatedAt"}:
                continue
            patch[key] = value

        status_changed = "status" in patch and patch["status"] != current["status"]
        if status_changed:
            # 红线：`评估完成` 只能走放行端点。
            # 这不是在限制人类（/approve 对任意状态都开放），而是让「放行」这件事
            # 永远只有一条可审计的通道 —— 判断"这是不是人类干的"只需看一个端点。
            if TaskStatus(patch["status"]) is TaskStatus.APPROVED:
                raise HTTPException(
                    status_code=400,
                    detail="`评估完成` 只能通过放行端点写入（POST /api/tasks/{id}/approve）",
                )
            patch["notes"] = append_note(current, require_note(body.note))

        if not patch:
            return current
        return store.update_record(
            root,
            "tasks",
            task_id,
            patch,
            expected_updated_at=body.expectedUpdatedAt,
        )

    @app.post("/api/tasks/{task_id}/approve")
    def approve_task(task_id: str, body: ApproveBody) -> dict:
        """唯一能把 status 写成 `评估完成` 的端点。

        对**任意状态**开放 —— 人类是外部来源，不需要向任何人申请就能放行。
        """
        reject_unknown_keys(body, "POST /api/tasks/{id}/approve")
        root = current_root()
        current = store.read_record(root, "tasks", task_id)
        status = TaskStatus(current["status"])

        if status is TaskStatus.APPROVED:
            raise store.Conflict("这条任务已经是评估完成")

        text = (body.note or "").strip() or "外部来源放行开发"
        if status is TaskStatus.NEW:
            # 留个痕迹：这条没经过分析师评估就被放行了，团队看到会知道为什么
            text = f"{text}（人类跳过分析师评估直接放行）"

        patch: dict = {
            "status": TaskStatus.APPROVED,
            "notes": append_note(current, text),
        }
        if body.priority is not None:
            patch["priority"] = body.priority
        if body.sprint is not None:
            patch["sprint"] = body.sprint

        return store.update_record(root, "tasks", task_id, patch, expected_updated_at=None)

    # ---------------- bug ----------------

    @app.post("/api/bugs")
    def create_bug(body: BugCreate) -> dict:
        reject_unknown_keys(body, "POST /api/bugs")
        root = current_root()
        notes: list[dict] = []
        if body.taskId is None:
            text = (body.note or "").strip()
            if not text:
                raise HTTPException(
                    status_code=400,
                    detail="bug 不关联任务时必须用 note 说明原因",
                )
            notes = [{"at": now_iso(), "by": "human", "text": text}]
        else:
            try:
                store.read_record(root, "tasks", body.taskId)
            except store.NotFound as exc:
                # 关联不存在的任务属于请求本身不合法 → 400（不是 404）
                raise HTTPException(
                    status_code=400, detail=f"关联的任务不存在：{body.taskId}"
                ) from exc
        return store.create_bug(
            root,
            title=body.title,
            severity=body.severity,
            taskId=body.taskId,
            steps=body.steps,
            expected=body.expected,
            actual=body.actual,
            env=body.env,
            notes=notes,
        )

    @app.patch("/api/bugs/{bug_id}")
    def patch_bug(bug_id: str, body: BugPatch) -> dict:
        reject_unknown_keys(body, "PATCH /api/bugs/{id}")
        root = current_root()
        current = store.read_record(root, "bugs", bug_id)

        patch: dict = {}
        for key, value in body.model_dump(exclude_unset=True).items():
            if key in {"note", "expectedUpdatedAt"}:
                continue
            patch[key] = value

        status_changed = "status" in patch and patch["status"] != current["status"]
        if status_changed:
            patch["notes"] = append_note(current, require_note(body.note))

        if not patch:
            return current
        return store.update_record(
            root, "bugs", bug_id, patch, expected_updated_at=body.expectedUpdatedAt
        )

    # ---------------- 站内信 ----------------

    @app.post("/api/messages")
    def create_message(body: MessageCreate) -> dict:
        reject_unknown_keys(body, "POST /api/messages")
        root = current_root()
        if body.inReplyTo is not None:
            try:
                store.read_record(root, "inbox", body.inReplyTo)
            except store.NotFound as exc:
                raise HTTPException(
                    status_code=400, detail=f"回复的消息不存在：{body.inReplyTo}"
                ) from exc
        return store.create_message(
            root,
            to=body.to,
            subject=body.subject,
            body=body.body,
            refs=body.refs.model_dump() if body.refs is not None else None,
            inReplyTo=body.inReplyTo,
        )

    # ---------------- 文档（只读） ----------------

    @app.get("/api/docs/{name}")
    def get_doc(name: str) -> dict:
        return store.read_doc(current_root(), name)

    # ---------------- 静态页面 ----------------

    @app.get("/")
    def index() -> FileResponse:
        return FileResponse(STATIC_DIR / "index.html")

    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
    return app


def main() -> None:
    parser = argparse.ArgumentParser(prog="niupeng-board", description="牛棚数据看板")
    parser.add_argument("--root", type=Path, default=None, help="项目目录（优先于已保存的配置）")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--host", default="127.0.0.1")
    args = parser.parse_args()

    # --root 优先且不回写配置文件；一次性指定不该改变长期配置
    root = args.root if args.root is not None else _load_config_root()
    app = create_app(root)
    uvicorn.run(app, host=args.host, port=args.port, log_level="info")


if __name__ == "__main__":  # pragma: no cover
    main()
